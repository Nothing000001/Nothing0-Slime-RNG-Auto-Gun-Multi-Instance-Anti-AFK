﻿#NoEnv
#Persistent
#SingleInstance Force
SetBatchLines -1

; ==========================================
; CONFIGURATION
; ==========================================
configFile := A_ScriptDir . "\settings.ini"
IniRead, toggleKey, %configFile%, Settings, ToggleKey, F1
IniRead, detectKey,  %configFile%, Settings, DetectKey,  F2
scriptActive := false
actionInterval := 60000
remainingTime := 60

Hotkey, %toggleKey%, ToggleScript, On
Hotkey, %detectKey%, DetectInstances, On

; ==========================================
; INTERFACE
; ==========================================
Gui, Color, 121212
Gui, Font, cFFFFFF s10, Segoe UI

Gui, Font, c00FFAA s16 Bold
Gui, Add, Text, x20 y15 w300 Center, Nothing0 AUTO GUN
Gui, Add, Progress, x20 y45 w300 h2 c00FFAA Background303030, 100

Gui, Font, cFFFFFF s10 Bold
Gui, Add, Text, x20 y65, Toggle Key
Gui, Font, c00FFAA s10
Gui, Add, Hotkey, vHotkeyChoice x150 y62 w90 h25, %toggleKey%
Gui, Add, Button, gApplyHotkey x250 y60 w70 h28, Save

Gui, Font, cFFFFFF s10 Bold
Gui, Add, Text, x20 y100, Detect Key
Gui, Font, c00FFAA s10
Gui, Add, Hotkey, vDetectChoice x150 y97 w90 h25, %detectKey%
Gui, Add, Button, gApplyDetect x250 y95 w70 h28, Save

Gui, Add, Progress, x20 y128 w300 h1 c333333 Background333333, 100

Gui, Font, cFFFFFF s10 Bold
Gui, Add, Text, x20 y140, Script Status
Gui, Font, cFF4444 s12 Bold
Gui, Add, Text, vStatusText x150 y137 w120, OFF

Gui, Font, cFFFFFF s10 Bold
Gui, Add, Text, x20 y170, Next Action
Gui, Font, cAAAAAA s10
Gui, Add, Text, vTimerText x150 y170 w150, --

Gui, Font, cFFFFFF s10 Bold
Gui, Add, Text, x20 y195, Instances
Gui, Font, c00FFAA s10 Bold
Gui, Add, Text, vInstanceText x150 y195 w150, 0 detected

Gui, Font, c666666 s8
Gui, Add, Text, x20 y225 w300 Center, Made by Nothing0

Gui, +AlwaysOnTop -MaximizeBox
Gui, Show, w340 h255, Nothing0 Auto Gun
Return

; ==========================================
; SAVE TOGGLE KEY
; ==========================================
ApplyHotkey:
Gui, Submit, NoHide
if (HotkeyChoice = "")
{
    MsgBox, 48, Error, Please choose a valid key.
    Return
}
Hotkey, %toggleKey%, Off
toggleKey := HotkeyChoice
Hotkey, %toggleKey%, ToggleScript, On
IniWrite, %toggleKey%, %configFile%, Settings, ToggleKey
TrayTip, No_Nothing, Toggle key saved: %toggleKey%, 2
Return

; ==========================================
; SAVE DETECT KEY
; ==========================================
ApplyDetect:
Gui, Submit, NoHide
if (DetectChoice = "")
{
    MsgBox, 48, Error, Please choose a valid key.
    Return
}
Hotkey, %detectKey%, Off
detectKey := DetectChoice
Hotkey, %detectKey%, DetectInstances, On
IniWrite, %detectKey%, %configFile%, Settings, DetectKey
TrayTip, No_Nothing, Detect key saved: %detectKey%, 2
Return

; ==========================================
; MANUAL DETECTION
; ==========================================
DetectInstances:
WinGet, robloxList, List, ahk_exe RobloxPlayerBeta.exe
GuiControl,, InstanceText, %robloxList% detected
TrayTip, No_Nothing, %robloxList% Roblox instance(s) detected!, 2
Return

; ==========================================
; TOGGLE ON/OFF
; ==========================================
ToggleScript:
scriptActive := !scriptActive
if (scriptActive)
{
    remainingTime := 60
    SetTimer, AutoAction, %actionInterval%
    SetTimer, UpdateCountdown, 1000
    Gui, Font, c00FF00 s12 Bold
    GuiControl, Font, StatusText
    GuiControl,, StatusText, ON
    GuiControl,, TimerText, %remainingTime%s
    SoundBeep, 1000, 100
}
else
{
    SetTimer, AutoAction, Off
    SetTimer, UpdateCountdown, Off
    Gui, Font, cFF4444 s12 Bold
    GuiControl, Font, StatusText
    GuiControl,, StatusText, OFF
    GuiControl,, TimerText, --
    GuiControl,, InstanceText, 0 detected
    SoundBeep, 500, 100
}
Return

; ==========================================
; COUNTDOWN TIMER
; ==========================================
UpdateCountdown:
if (!scriptActive)
    Return
remainingTime--
if (remainingTime < 0)
    remainingTime := 60
GuiControl,, TimerText, %remainingTime%s
Return

; ==========================================
; MAIN ACTION - MULTI INSTANCE
; ==========================================
AutoAction:
if (!scriptActive)
    Return
remainingTime := 60

WinGet, robloxList, List, ahk_exe RobloxPlayerBeta.exe
GuiControl,, InstanceText, %robloxList% detected

if (robloxList = 0)
{
    TrayTip, No_Nothing, No Roblox instance detected!, 2
    Return
}

WinGet, previousHwnd, ID, A

Loop, %robloxList%
{
    robloxHwnd := robloxList%A_Index%

    if !WinExist("ahk_id " . robloxHwnd)
        Continue

    WinActivate, ahk_id %robloxHwnd%
    WinWaitActive, ahk_id %robloxHwnd%,, 3
    if (ErrorLevel)
        Continue

    Sleep, 400

    ; Activate gun
    Click down
    Send, {Esc}
    Click up
    Send, {Esc}
    Sleep, 500

    ; Check if Escape menu is still open
    CoordMode, Pixel, Window
    PixelSearch, Px, Py, 830, 640, 1050, 710, 0x4C6EF5, 30, Fast RGB
    if (ErrorLevel = 0)
    {
        SendInput, {Esc}
        Sleep, 300
        PixelSearch, Px, Py, 830, 640, 1050, 710, 0x4C6EF5, 30, Fast RGB
        if (ErrorLevel = 0)
            SendInput, {Esc}
    }

    Sleep, 500
}

if (previousHwnd)
    WinActivate, ahk_id %previousHwnd%
Return

; ==========================================
; CLOSE
; ==========================================
GuiEscape:
GuiClose:
ExitApp
Return