﻿#NoEnv
#SingleInstance Force

WinGet, list, List
Loop, %list%
{
    hwnd := list%A_Index%
    WinGetTitle, title, ahk_id %hwnd%
    WinGet, exe, ProcessName, ahk_id %hwnd%
    if (title != "")
        result .= exe . " | " . title . "`n"
}
MsgBox, %result%