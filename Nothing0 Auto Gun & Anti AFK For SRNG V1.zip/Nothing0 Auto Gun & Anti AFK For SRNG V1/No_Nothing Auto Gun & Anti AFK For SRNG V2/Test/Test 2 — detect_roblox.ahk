﻿#NoEnv
#SingleInstance Force

; Test WinExist
if WinExist("ahk_exe RobloxPlayerBeta.exe")
    MsgBox, Roblox FOUND via WinExist!
else
    MsgBox, Roblox NOT found via WinExist...

; Test WinGet List
F2::
WinGet, robloxList, List, ahk_exe RobloxPlayerBeta.exe
MsgBox, Instances found: %robloxList%`n`nHwnd1: %robloxList1%
Return