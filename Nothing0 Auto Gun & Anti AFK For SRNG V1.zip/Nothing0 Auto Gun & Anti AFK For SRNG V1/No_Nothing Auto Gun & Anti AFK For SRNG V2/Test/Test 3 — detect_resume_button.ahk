﻿#NoEnv
#SingleInstance Force

; Open Roblox, open the Escape menu
; then press F3 to test detection
F3::
CoordMode, Pixel, Window
PixelSearch, Px, Py, 830, 640, 1050, 710, 0x4C6EF5, 30, Fast RGB
if (ErrorLevel = 0)
    MsgBox, Resume button DETECTED! Position: %Px% / %Py%
else
    MsgBox, Resume button NOT detected...`nTry adjusting the color or search area.
Return